const express = require('express');
const router = express.Router();
const Teacher=require("../models/teacher");
const Student=require("../models/student");
router.get('/', async(req, res) => {
  res.render('template');
});
router.get('/teacher', async(req, res) => {
  res.render('teacherpage',{ error:''});
});
router.post('/teacher', async (req, res) => {
  const { registerNumber, password } = req.body;

  try {
    const teacher = await Teacher.findOne({
      where: { registerNumber, password },
    });

    if (teacher) {
      // Successful login, navigate to the next page
      res.redirect('/teacherdash'); // Change to the appropriate route
    } else {
      // Incorrect login details, display an error
      res.render('teacherpage', { error: 'Invalid credentials' });
    }
  } catch (error) {
    console.error('Error during login:', error);
    res.render('teacherpage', { error: 'An error occurred during login' });
  }
});
router.get('/teacherdash', async (req, res) => {
  try {
    const students = await Student.findAll(); // Fetch all student records
    res.render('teacherdashboard', { students }); // Render the dashboard page with student data
  } catch (error) {
    console.error('Error fetching student records:', error);
    res.render('teacherdashboard', { error: 'An error occurred' });
  }
});
router.get('/teacherlogout', (req, res) => {
  // Implement logout logic here
  res.redirect('/'); // Redirect to the index page
});
router.post('/addrecord', async (req, res) => {
  const { rollno, dob, name, score } = req.body;
  try {
    // Insert the new student record into the database
    await Student.create({
      rollno,
      dob,
      name,
      score,
    });
    res.redirect('/teacherdash?message=Record added successfully');
    // res.render('addRecord', { message: 'Student record added successfully!' });
  } catch (error) {
    console.error('Error adding student record:', error);
    res.render('addRecord', { error: 'Please enter valid details of the student' });
  }
});
router.get('/addrecord', (req, res) => {
  // Implement logout logic here
  res.render('addRecord',{ error:''}); // Redirect to the index page
});

router.get('/student', async(req,res)=>{
  res.render('studentpage',{ error:''});
});
router.post('/student', async (req, res) => {
  const { rollno, name } = req.body;

  try {
    const student = await Student.findOne({
      where: { rollno, name },
    });

    if (student) {
      res.redirect(`/student/dashboard/${student.rollno}`);
    } else {
      res.render('studentpage', { error: 'Invalid credentials' });
    }
  } catch (error) {
    console.error('Error during student login:', error);
    res.render('studentpage', { error: 'An error occurred during login' });
  }
});
router.get('/student/dashboard/:id', async (req, res) => {
  const studentId = req.params.id;

  try {
    const student = await Student.findByPk(studentId);

    if (student) {
      res.render('studentdashboard', { student });
    } else {
      res.render('studentpage', { error: 'Student not found' });
    }
  } catch (error) {
    console.error('Error fetching student data:', error);
    res.render('stuentpage', { error: 'An error occurred' });
  }
});
router.get('/studentlogout', (req, res) => {
  // Implement logout logic here
  res.redirect('/'); // Redirect to the index page
});

router.get('/delete/:id', async (req, res) => {
  const studentId = req.params.id;

  try {
    // Find the student record by ID
    const student = await Student.findByPk(studentId);


    // Delete the student record
    await student.destroy();

    res.redirect('/teacherdash'); // Redirect to the dashboard after deletion
  } catch (error) {
    console.error('Error deleting student:', error);
    res.render('teacherdashboard', { error: 'An error occurred' });
  }
});

// edit.js
router.get('/edit/:id', async (req, res) => {
  const studentId = req.params.id;

  try {
    // Find the student record by ID
    const student = await Student.findByPk(studentId);

    if (!student) {
      res.redirect('/teacerdashb'); // Redirect to the dashboard if student is not found
      return;
    }

    res.render('edit', { student }); // Render the edit form with student data
  } catch (error) {
    console.error('Error fetching student for edit:', error);
    res.redirect('/teacherdash'); // Redirect to the dashboard in case of an error
  }
});

router.post('/edit/:id', async (req, res) => {
  const studentId = req.params.id;
  const { dateOfBirth, name, score } = req.body;

  try {
    // Find the student record by ID
    const student = await Student.findByPk(studentId);

    if (!student) {
      res.redirect('/teacherdash'); // Redirect to the dashboard if student is not found
      return;
    }

    // Update student data
    student.dob = dateOfBirth;
    student.name = name;
    student.score = score;
    await student.save();

    res.redirect('/teacherdash'); // Redirect to the dashboard after editing
  } catch (error) {
    console.error('Error editing student:', error);
    res.redirect('/teacherdash'); // Redirect to the dashboard in case of an error
  }
});




// Add more routes for student and teacher actions

module.exports = router;
